const fs = require('fs');
const path = require('path');

const wwwDir = path.join(__dirname, '..', 'www');
fs.mkdirSync(wwwDir, { recursive: true });

fs.writeFileSync(
  path.join(wwwDir, 'index.html'),
  `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>6C</title>
    <style>
      html, body {
        height: 100%;
        margin: 0;
        background: #ffffff;
        color: #111827;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      main {
        min-height: 100%;
        display: grid;
        place-items: center;
        padding: 24px;
        text-align: center;
      }

      h1 {
        margin: 0 0 8px;
        font-size: 28px;
      }

      p {
        margin: 0;
        color: #4b5563;
        line-height: 1.5;
      }

      a {
        color: #0a66c2;
      }
    </style>
  </head>
  <body>
    <main>
      <div>
        <h1>6C</h1>
        <p>If the app does not open automatically, visit <a href="https://5c.wuaze.com">5c.wuaze.com</a>.</p>
      </div>
    </main>
  </body>
</html>
`,
  'utf8'
);

console.log('Built www/index.html');
