# 6C iPhone App

This repository contains the iOS wrapper app for **6C**.

The app opens:

https://5c.wuaze.com

## App Store Connect values

- App name: `6C`
- Bundle ID: `com.wuaze.app6c`
- SKU: `6C-20261005`
- Platform: iOS

## Codemagic setup

1. Connect this GitHub repository to Codemagic.
2. Add an Apple Developer integration in Codemagic.
3. Enable iOS code signing for bundle ID `com.wuaze.app6c`.
4. Run the `6C iOS Release` workflow.

Do not commit Codemagic API keys, Apple API keys, `.p12` files, or provisioning profiles into GitHub.

## Local build

```bash
npm install
npm run build
npx cap add ios
npm run sync:ios
```

## App Review note draft

Hello App Review Team,

6C is an iPhone app for users of the 6C service. The app opens the secure web service at https://5c.wuaze.com and provides mobile access to the service in an iOS app experience.

There is no paid content, no in-app purchases, and no public user-generated content. If login is required during review, please use the test credentials provided in the App Review Information section.

The app uses HTTPS and does not require special regional behavior.
