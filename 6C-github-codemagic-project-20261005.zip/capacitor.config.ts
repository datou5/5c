import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.wuaze.app6c',
  appName: '6C',
  webDir: 'www',
  server: {
    url: 'https://5c.wuaze.com',
    cleartext: false
  },
  ios: {
    contentInset: 'automatic',
    scrollEnabled: true
  }
};

export default config;
